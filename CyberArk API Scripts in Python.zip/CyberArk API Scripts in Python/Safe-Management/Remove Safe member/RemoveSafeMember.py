import requests
import getpass
import json
from datetime import datetime
from datetime import date

# USER TO UPDATE THE PVWA BASE ADDRESS (For E.g., cyberark.company.com)
PVWABaseURL = "pvwalb.company.com" # -- PLEASE CHANGE HERE -- #

# API URLs for the specific function, please refer the cyberark documentation for the list of URls
LogonUrl = 'https://%s/PasswordVault/API/Auth/CyberArk/Logon' % PVWABaseURL
SafeCreationUrl = 'https://%s/PasswordVault/WebServices/PIMServices.svc/Safes' % PVWABaseURL
AddSafeMemberUrl = 'https://%s/PasswordVault/WebServices/PIMServices.svc/Safes/' % PVWABaseURL
Logoffurl = 'https://%s/PasswordVault/API/Auth/Logoff' % PVWABaseURL

# Declaring output file for logging
output = open("Remove-SafeMember_Output.txt", 'a')

now = datetime.now()
today = date.today()
output.write("\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                                Script Execution 'BEGIN' TimeSTamp : %s - %s  \n------------------------------------------------------------------------------------------------------------------------------------------------------" %(today.strftime("%b-%d-%Y"), now.strftime("%H:%M:%S")))

PayLoad = {}

# Declaring Variables for Userid & Password Prompts
userid = input("\nEnter Vault UserName: ")
passwd = getpass.getpass(prompt=('Enter (%s) Password: ') % userid)

AuthPayload = "{\r\n  \"username\":\"%s\",\r\n  \"password\":\"%s\",\n}" % (userid, passwd)
AuthHeaders = {'Content-Type': 'application/json'}

# Passing the credentials from the above declared variables to Authenticate to vault
AuthResponse = requests.request('POST', LogonUrl, headers=AuthHeaders, data=AuthPayload, allow_redirects=False, verify=True)
AuthToken = AuthResponse.text[1:-1]

# Validating Authentication using the credentials that user used.
if str(AuthResponse) != "<Response [200]>":
    print("\nAuthentication to vault is unsuccessful. Quitting!!\n")
    exit()
elif str(AuthResponse) == "<Response [200]>":
    print("\nAuthentication to vault is successful.!!\n")

# Declaring the Token header for subsequent API calls
Tokenheaders = {'Authorization': AuthToken, 'Content-Type': 'application/json', 'connection': 'keep-alive'}


with open("Remove-SafeMember-Data.csv") as SafeMemberList:
    for lin in SafeMemberList:
        if not lin.startswith("SafeName,memberName,"):
            line = lin.strip().split(',')
            line = [x.replace("TRUE", "true").replace("FALSE", "false") for x in line]
# Getting the Safe Properties
            SearchSafeResponse = requests.request('GET', (AddSafeMemberUrl + line[0]), timeout=60, headers=Tokenheaders, allow_redirects=False, verify=True)
            GetSafeJSONCount = json.loads(SearchSafeResponse.text)
            SafeValidation = str(GetSafeJSONCount).split(',')

            if str(SearchSafeResponse) == "<Response [200]>" and (SafeValidation[1]) != " \'ErrorMessage\': \'Safe [%s] was not found\'}" % (line[0]):
                GetSafeMemberResponse = requests.request('GET', (AddSafeMemberUrl + str(line[0]) + "/Members"), timeout=60, headers=Tokenheaders, allow_redirects=False,verify=True)
                GetSafeMemberCount = json.loads(GetSafeMemberResponse.text)

# Getting the Current Safe Members

                GetSafeMemberList = []

                for user in GetSafeMemberCount['members']:
                    GetSafeMemberList.append(user['UserName'])

                if line[1] in GetSafeMemberList:
# Removing the requested Safe Members
                    SafeMemberDeleteresponse = requests.request('DELETE', (SafeCreationUrl + "/" + line[0] + "/Members" + "/" + line[1]), timeout=60, headers=Tokenheaders, data=PayLoad, allow_redirects=False, verify=True)
                    output.write("\nRemoving user '%s' on safe '%s' : HTTP" % (line[1], line[0]) + str(SafeMemberDeleteresponse) + "\n")

                    if str(SafeMemberDeleteresponse) == "<Response [200]>":
                        output.write("\nRemoving user '%s' on safe '%s' is SUCCESSFUL: HTTP %s" % (line[1], line[0], str(SafeMemberDeleteresponse)))
                    else:
                        output.write("\nRemoving user '%s' on safe '%s' FAILED: HTTP Response:" % (line[1], line[0], str(SafeMemberDeleteresponse.text)))

                else:
                    output.write("\nUser '%s' does not have access to the safe '%s' " % (line[1], line[0]))

# Validating if the Safe Exists
            elif (SafeValidation[1]) == " \'ErrorMessage\': \'Safe [%s] was not found\'}" % (line[0]) or (SafeValidation[1]) == " \'ErrorMessage\': \'Safe %s has been deleted or does not exist.\'}" % (line[0]):
                print("\nSafe %s does not exist." % line[0])
                output.write("\nSafe %s does not exist." % line[0])

# LOGOFF FROM VAULT.
output.write("\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                                Script Execution 'END' TimeSTamp : %s - %s  \n------------------------------------------------------------------------------------------------------------------------------------------------------\n" %(today.strftime("%b-%d-%Y"), now.strftime("%H:%M:%S")))

LogOffresponse = requests.request('POST', Logoffurl, timeout=30, headers=Tokenheaders, data=PayLoad, allow_redirects=False, verify=True)
output.close()
