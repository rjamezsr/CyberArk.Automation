import requests
import getpass
import json
from datetime import datetime
from datetime import date

# USER TO UPDATE THE PVWA BASE ADDRESS (For E.g., cyberark.company.com)
PVWABaseURL = "pvwalb.company.com"  # -- PLEASE CHANGE HERE -- #

# API URLs for the specific function, please refer the cyberark documentation for the list of URls
LogonUrl = 'https://%s/PasswordVault/API/Auth/CyberArk/Logon' % PVWABaseURL
SafeCreationUrl = 'https://%s/PasswordVault/WebServices/PIMServices.svc/Safes' % PVWABaseURL
Logoffurl = 'https://%s/PasswordVault/API/Auth/Logoff' % PVWABaseURL

# Declaring output file for logging
output = open("CreateUpdate_Safes_output.txt", 'a')

now = datetime.now()
today = date.today()
output.write("\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                                Script Execution 'BEGIN' TimeSTamp : %s - %s  \n" %(today.strftime("%b-%d-%Y"), now.strftime("%H:%M:%S")))

PayLoad = {}

# Declaring Variables for Userid & Password Prompts
userid = input("\nEnter Vault UserName: ")
passwd = getpass.getpass(prompt=('Enter (%s) Password: ') % userid)

AuthPayload = "{\r\n  \"username\":\"%s\",\r\n  \"password\":\"%s\",\n}" % (userid, passwd)
AuthHeaders = {'Content-Type': 'application/json'}

# Passing the credentials from the above declared variables to Authenticate to vault
AuthResponse = requests.request('POST', LogonUrl, headers=AuthHeaders, data=AuthPayload, allow_redirects=False, verify=True)
AuthToken = AuthResponse.text[1:-1]

# Validating Authentication using the credentials that user used.
if str(AuthResponse) != "<Response [200]>":
    print("\nAuthentication to vault is unsuccessful. Quitting!!\n")
    exit()
elif str(AuthResponse) == "<Response [200]>":
    print("\nAuthentication to vault is successful.!!\n")

# Declaring the Token header for subsequent API calls
Tokenheaders = {'Authorization': AuthToken, 'Content-Type': 'application/json', 'connection': 'keep-alive'}


with open("CreateUpdate_Safes_data.csv") as SafeMemberList:
    for lin in SafeMemberList:
        if not lin.startswith("SafeName,newSafeName"):
            line = lin.strip().split(',')
# Getting the Safe Properties
            SearchSafeResponse = requests.request('GET', (SafeCreationUrl + "/" + line[0]), timeout=60, headers=Tokenheaders, allow_redirects=False, verify=True)
            GetSafeJSONCount = json.loads(SearchSafeResponse.text)
            SafeValidation = str(GetSafeJSONCount).split(',')

            if str(SearchSafeResponse) == "<Response [200]>" and (SafeValidation[1]) != " \'ErrorMessage\': \'Safe [%s] was not found\'}" % (line[0]):
                output.write("\nRetrieving the Safe %s properties. HTTP Response : %s" % (line[0], str(SearchSafeResponse)))

                SafePayload = ("{\n    \"safe\":{\n        \"SafeName\":\"%s\",\n        \"Description\":\"%s\",\n        \"OLACEnabled\":false,\n        \"ManagingCPM\":\"%s\",\n        \"NumberofVersionsRetention\":%s,\n        \"NumberofDaysRetention\":%s\n    }\n}" % (line[1],line[2],line[3],str(line[4]),str(line[5])))
                SafeCreationresponse = requests.request('PUT', (SafeCreationUrl + "/" + line[0]), timeout=60, headers=Tokenheaders, data=SafePayload, allow_redirects=False, verify=True)

                if str(SafeCreationresponse) == "<Response [200]>" :
                    output.write("\nSafe '%s' update is \"SUCCESS\".HTTP Response: %s" % (line[1], str(SafeCreationresponse)))
                else:
                    output.write("\nSafe '%s' update \"Failed\".HTTP Response: %s" % (line[1], str(SafeCreationresponse)))

# Validating if the Safe Exists
            elif (SafeValidation[1]) == " \'ErrorMessage\': \'Safe [%s] was not found\'}" % (line[0]) or (SafeValidation[1]) == " \'ErrorMessage\': \'Safe %s has been deleted or does not exist.\'}" % (line[0]):
                print("\nSafe %s does not exist. Creating the Safe now " % line[0])
                output.write("\nSafe %s does not exist. Creating the Safe now " % line[0])

                SafePayload = ("{\n    \"safe\":{\n        \"SafeName\":\"%s\",\n        \"Description\":\"%s\",\n        \"OLACEnabled\":false,\n        \"ManagingCPM\":\"%s\",\n        \"NumberofVersionsRetention\":%s,\n        \"NumberofDaysRetention\":%s\n    }\n}" % (line[0],line[2],line[3],str(line[4]),str(line[5])))
# Creating the Safe
                SafeCreationresponse = requests.request('POST', SafeCreationUrl, timeout=60, headers=Tokenheaders, data=SafePayload, allow_redirects=False, verify=True)

                if str(SafeCreationresponse) == "<Response [200]>" :
                    output.write("\nSafe '%s' creation is \"SUCCESS\".HTTP Response: %s" % (line[1], str(SafeCreationresponse)))
                else:
                    output.write("\nSafe '%s' creation \"Failed\".HTTP Response: %s" % (line[1], str(SafeCreationresponse)))

# LOGOFF FROM VAULT.
output.write("\n------------------------------------------------------------------------------------------------------------------------------------------------------                                Script Execution 'END' TimeSTamp : %s - %s  \n" %(today.strftime("%b-%d-%Y"), now.strftime("%H:%M:%S")))

LogOffresponse = requests.request('POST', Logoffurl, timeout=30, headers=Tokenheaders, data=PayLoad, allow_redirects=False, verify=True)
output.close()
