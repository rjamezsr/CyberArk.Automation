import requests
import getpass
import json
from datetime import datetime
from datetime import date

# USER TO UPDATE THE PVWA BASE ADDRESS (For E.g., cyberark.company.com)
PVWABaseURL = "pvwalb.company.com" # -- PLEASE CHANGE HERE -- #

# API URLs for the specific function, please refer the cyberark documentation for the list of URls
LogonUrl = 'https://%s/PasswordVault/API/Auth/CyberArk/Logon' % PVWABaseURL
SafeCreationUrl = 'https://%s/PasswordVault/WebServices/PIMServices.svc/Safes' % PVWABaseURL
AddSafeMemberUrl = 'https://%s/PasswordVault/WebServices/PIMServices.svc/Safes/' % PVWABaseURL
Logoffurl = 'https://%s/PasswordVault/API/Auth/Logoff' % PVWABaseURL

# Declaring output file for logging
output = open("AU-SafeMember_OutPut.txt", 'a')

now = datetime.now()
today = date.today()
output.write("\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                                Script Execution 'BEGIN' TimeSTamp : %s - %s  \n------------------------------------------------------------------------------------------------------------------------------------------------------" %(today.strftime("%b-%d-%Y"), now.strftime("%H:%M:%S")))

PayLoad = {}

# Declaring Variables for Userid & Password Prompts
userid = input("\nEnter Vault UserName: ")
passwd = getpass.getpass(prompt=('Enter (%s) Password: ') % userid)

AuthPayload = "{\r\n  \"username\":\"%s\",\r\n  \"password\":\"%s\",\n}" % (userid, passwd)
AuthHeaders = {'Content-Type': 'application/json'}

# Passing the credentials from the above declared variables to Authenticate to vault
AuthResponse = requests.request('POST', LogonUrl, headers=AuthHeaders, data=AuthPayload, allow_redirects=False, verify=True)
AuthToken = AuthResponse.text[1:-1]

# Validating Authentication using the credentials that user used.
if str(AuthResponse) != "<Response [200]>":
    print("\nAuthentication to vault is unsuccessful. Quitting!!\n")
    exit()
elif str(AuthResponse) == "<Response [200]>":
    print("\nAuthentication to vault is successful.!!\n")

# Declaring the Token header for subsequent API calls
Tokenheaders = {'Authorization': AuthToken, 'Content-Type': 'application/json', 'connection': 'keep-alive'}


with open("AU-SafeMember-Data.csv") as SafeMemberList:
    for lin in SafeMemberList:
        if not lin.startswith("SafeName,memberName,"):
            line = lin.strip().split(',')
            line = [x.replace("TRUE", "true").replace("FALSE", "false") for x in line]
# Getting the Safe Properties
            SearchSafeResponse = requests.request('GET', (AddSafeMemberUrl + line[0]), timeout=60, headers=Tokenheaders, allow_redirects=False, verify=True)
            GetSafeJSONCount = json.loads(SearchSafeResponse.text)
            SafeValidation = str(GetSafeJSONCount).split(',')

            if str(SearchSafeResponse) == "<Response [200]>" and (SafeValidation[1]) != " \'ErrorMessage\': \'Safe [%s] was not found\'}" % (line[0]):
                output.write("\nRetrieving the Safe %s properties. HTTP Response : %s" % (line[0], str(SearchSafeResponse)))
                print ("\nRetrieving the Safe %s properties. HTTP Response : %s" % (line[0], str(SearchSafeResponse)))

# Validating if the Safe Exists
            elif (SafeValidation[1]) == " \'ErrorMessage\': \'Safe [%s] was not found\'}" % (line[0]) or (SafeValidation[1]) == " \'ErrorMessage\': \'Safe %s has been deleted or does not exist.\'}" % (line[0]):
                print("\nSafe %s does not exist. Creating the Safe now " % line[0])
                output.write("\nSafe %s does not exist. Creating the Safe now " % line[0])

                SafePayload = ("{\n\"safe\":{\n\"SafeName\":\"%s\",\n\"Description\":\"\",\n\"OLACEnabled\":false,\n\"ManagingCPM\":\"\",\n\"NumberofVersionsRetention\":5,\n\"NumberofDaysRetention\":7\n  }\n}" % line[0])
# Creating the Safe
                SafeCreationresponse = requests.request('POST', SafeCreationUrl, timeout=60, headers=Tokenheaders, data=SafePayload, allow_redirects=False, verify=True)
                output.write("\nSafe \'%s\' Creation : HTTP Response : %s " % (line[0] , str(SafeCreationresponse)))
                print("\nSafe \'%s\' Creation : HTTP Response : %s " % (line[0], str(SafeCreationresponse)))

            GetSafeMemberResponse = requests.request('GET', (AddSafeMemberUrl + str(line[0]) + "/Members"), timeout=60, headers=Tokenheaders, allow_redirects=False, verify=True)
            GetSafeMemberCount = json.loads(GetSafeMemberResponse.text)

# Getting the Current Safe Members
            AddMemberPayload = "{\n  \"member\": {\n    \"MemberName\":\"%s\",\n    \"SearchIn\":\"%s\",\n    \"MembershipExpirationDate\":\"\",\n    \"Permissions\":\n     [\n       {\"Key\":\"UseAccounts\", \"Value\":%s},\n       {\"Key\":\"RetrieveAccounts\", \"Value\":%s},\n       {\"Key\":\"ListAccounts\", \"Value\":%s},\n       {\"Key\":\"AddAccounts\", \"Value\":%s},\n       {\"Key\":\"UpdateAccountContent\", \"Value\":%s},\n       {\"Key\":\"UpdateAccountProperties\", \"Value\":%s},\n       {\"Key\":\"InitiateCPMAccountManagementOperations\", \"Value\":%s},\n       {\"Key\":\"SpecifyNextAccountContent\", \"Value\":%s},\n       {\"Key\":\"RenameAccounts\", \"Value\":%s},\n       {\"Key\":\"DeleteAccounts\", \"Value\":%s},\n       {\"Key\":\"UnlockAccounts\", \"Value\":%s},\n       {\"Key\":\"ManageSafe\", \"Value\":%s},\n       {\"Key\":\"ManageSafeMembers\", \"Value\":%s},\n       {\"Key\":\"BackupSafe\", \"Value\":%s},\n       {\"Key\":\"ViewAuditLog\", \"Value\":%s},\n       {\"Key\":\"ViewSafeMembers\", \"Value\":%s},\n       {\"Key\":\"RequestsAuthorizationLevel\", \"Value\":%s},\n       {\"Key\":\"AccessWithoutConfirmation\", \"Value\":%s},\n       {\"Key\":\"CreateFolders\", \"Value\":%s},\n       {\"Key\":\"DeleteFolders\", \"Value\":%s},\n       {\"Key\":\"MoveAccountsAndFolders\", \"Value\":%s}\n     ]\n  }\n}" % (line[1], line[2], line[3], line[4], line[5], line[6], line[7], line[8], line[9], line[10], line[11], line[12], line[13], line[14], line[15], line[16], line[17], line[18], line[19], line[20], line[21], line[22], line[23])
            UpdateMemberPayload = "{\n  \"member\": {\n,\n    \"MembershipExpirationDate\":\"\",\n    \"Permissions\":\n     [\n       {\"Key\":\"UseAccounts\", \"Value\":%s},\n       {\"Key\":\"RetrieveAccounts\", \"Value\":%s},\n       {\"Key\":\"ListAccounts\", \"Value\":%s},\n       {\"Key\":\"AddAccounts\", \"Value\":%s},\n       {\"Key\":\"UpdateAccountContent\", \"Value\":%s},\n       {\"Key\":\"UpdateAccountProperties\", \"Value\":%s},\n       {\"Key\":\"InitiateCPMAccountManagementOperations\", \"Value\":%s},\n       {\"Key\":\"SpecifyNextAccountContent\", \"Value\":%s},\n       {\"Key\":\"RenameAccounts\", \"Value\":%s},\n       {\"Key\":\"DeleteAccounts\", \"Value\":%s},\n       {\"Key\":\"UnlockAccounts\", \"Value\":%s},\n       {\"Key\":\"ManageSafe\", \"Value\":%s},\n       {\"Key\":\"ManageSafeMembers\", \"Value\":%s},\n       {\"Key\":\"BackupSafe\", \"Value\":%s},\n       {\"Key\":\"ViewAuditLog\", \"Value\":%s},\n       {\"Key\":\"ViewSafeMembers\", \"Value\":%s},\n       {\"Key\":\"RequestsAuthorizationLevel\", \"Value\":%s},\n       {\"Key\":\"AccessWithoutConfirmation\", \"Value\":%s},\n       {\"Key\":\"CreateFolders\", \"Value\":%s},\n       {\"Key\":\"DeleteFolders\", \"Value\":%s},\n       {\"Key\":\"MoveAccountsAndFolders\", \"Value\":%s}\n     ]\n  }\n}" % (line[3], line[4], line[5], line[6], line[7], line[8], line[9], line[10], line[11], line[12], line[13], line[14], line[15], line[16], line[17], line[18], line[19], line[20], line[21], line[22], line[23])

            GetSafeMemberList = []

            for user in GetSafeMemberCount['members']:
                GetSafeMemberList.append(user['UserName'])

            if line[1] in GetSafeMemberList:
# Updating the Current Safe Members
                UpdateSafeMemberResponse = requests.request('POST', (AddSafeMemberUrl + line[0]  + "/Members/" + line[1]), timeout=60, headers=Tokenheaders, data=UpdateMemberPayload, allow_redirects=False, verify=True)
                output.write("\nUpdating \'%s\' on safe \'%s\' : HTTP Response : %s " % (line[1], line[0] ,str(AddSafeMemberResponse)))
                print("Updating \'%s\' on safe \'%s\' : HTTP Response : %s " % (line[1], line[0], str(UpdateSafeMemberResponse)))

            else:
# # Adding the New Safe Members
                AddSafeMemberResponse = requests.request('POST', (AddSafeMemberUrl  + line[0] + "/Members"), timeout=60, headers=Tokenheaders, data=AddMemberPayload, allow_redirects=False, verify=True)
                output.write("\nAdding \'%s\' on safe \'%s\' : HTTP Response : %s " % (line[1], line[0] ,str(AddSafeMemberResponse)))
                print("Adding \'%s\' on safe \'%s\' : HTTP Response : %s " % (line[1], line[0], str(AddSafeMemberResponse)))

# # STEP:4     REMOVE THE SAFE_MEMBERSHIP OF THE VAULT USER, THAT WAS USED TO THE CREATE  THE SAFES. -- OPTIONAL STEP IF NEEDED
#
             # SafeMemberDeleteresponse = requests.request('DELETE', (SafeCreationUrl + "/" + line[0] + "/Members"+"/" + userid), timeout=60, headers=Tokenheaders, data=PayLoad, allow_redirects=False, verify=True)
             # Output.write("\nRemoving user '%s' on safe '%s' : HTTP" % (userid, line[0]) + str(SafeMemberDeleteresponse)+"\n")
             # print("Removing user '%s' on safe '%s' : HTTP" % (userid, line[0]), SafeMemberDeleteresponse)

# LOGOFF FROM VAULT.
output.write("\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                                Script Execution 'END' TimeSTamp : %s - %s  \n------------------------------------------------------------------------------------------------------------------------------------------------------\n" %(today.strftime("%b-%d-%Y"), now.strftime("%H:%M:%S")))

LogOffresponse = requests.request('POST', Logoffurl, timeout=30, headers=Tokenheaders, data=PayLoad, allow_redirects=False, verify=True)
output.close()
