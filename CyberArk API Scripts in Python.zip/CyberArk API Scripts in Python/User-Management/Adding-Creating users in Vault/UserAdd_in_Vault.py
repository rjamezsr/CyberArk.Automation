import requests
import getpass
import json
from datetime import datetime
from datetime import date

# USER TO UPDATE THE PVWA BASE ADDRESS (For E.g., cyberark.company.com)
PVWABaseURL = "pvwalb.company.com" # -- PLEASE CHANGE HERE -- #

# API URLs for the specific function, please refer the cyberark documentation for the list of URls
LogonUrl = 'https://%s/PasswordVault/API/Auth/CyberArk/Logon' % PVWABaseURL
LogoffUrl = 'https://%s/PasswordVault/API/Auth/Logoff' % PVWABaseURL
GetAddUsersUrl = 'https://%s/PasswordVault/api/Users' % PVWABaseURL
GetAddGroupsUrl = 'https://%s/PasswordVault/api/UserGroups' % PVWABaseURL

# Declaring output file for logging
output = open("UserCreation_OutPut.txt", 'a')

now = datetime.now()
today = date.today()
output.write("\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                                Script Execution 'BEGIN' TimeSTamp : %s - %s  \n------------------------------------------------------------------------------------------------------------------------------------------------------" %(today.strftime("%b-%d-%Y"), now.strftime("%H:%M:%S")))

PayLoad = {}

# Declaring Variables for Userid & Password Prompts
userid = input("\nEnter Vault UserName: ")
passwd = getpass.getpass(prompt=('Enter (%s) Password: ') % userid)

AuthPayload = "{\r\n  \"username\":\"%s\",\r\n  \"password\":\"%s\",\n}" % (userid, passwd)
AuthHeaders = {'Content-Type': 'application/json'}

# Passing the credentials from the above declared variables to Authenticate to vault
AuthResponse = requests.request('POST', LogonUrl, headers=AuthHeaders, data=AuthPayload, allow_redirects=False, verify=True)
AuthToken = AuthResponse.text[1:-1]

# Validating Authentication using the credentials that user used.
if str(AuthResponse) != "<Response [200]>":
    print("\nAuthentication to vault is unsuccessful. Quitting!!\n")
    exit()
elif str(AuthResponse) == "<Response [200]>":
    print("\nAuthentication to vault is successful.!!\n")

# Declaring the Token header for subsequent API calls
Tokenheaders = {'Authorization': AuthToken, 'Content-Type': 'application/json', 'connection': 'keep-alive'}

with open("UserAdd_Data.csv", 'r') as data:
    ColnHeader = list(next(data).split(','))
    ColnHeader = [colns.strip() for colns in ColnHeader]

userloaddict = {}

#Function to serialize and format the JSON payload needed for user creation.
def UserPayLoad(line):
    line = line.strip()
    value = line.split(',')
    value = [val.replace(';','\",\"') for val in value]

    #userloaddict = {}
    AddUserPayLoadColumns = ["username", "userType", "initialPassword", "authenticationMethod", "location", "unAuthorizedInterfaces", "expiryDate", "vaultAuthorization",
                             "enableUser","changePassOnNextLogon", "passwordNeverExpires", "distinguishedName", "description", "workStreet", "workCity", "workState",
                             "workZip", "workCountry", "homePage", "homeEmail", "businessEmail", "otherEmail", "homeNumber", "businessNumber", "cellularNumber", "faxNumber",
                             "pagerNumber", "street", "city", "state", "zip", "country", "title", "organization", "department", "profession", "firstName", "middleName", "lastName"]

    for colns in ColnHeader:
        index = ColnHeader.index(colns)
        if colns in AddUserPayLoadColumns:
            userloaddict[colns] = value[index]

    AddUserPayload = "{"
    BusinessAdd = "\n    \"businessAddress\":\n     {"
    internet = "\n    \"internet\":\n     {"
    phone = "\n    \"phones\": {"
    personal = "\n  \"personalDetails\": {"

    for key in userloaddict:
        if key in AddUserPayLoadColumns[:12]:
            if key == "authenticationMethod" or key == "unAuthorizedInterfaces" or key == "vaultAuthorization":
                AddUserPayload = AddUserPayload + "\n    \"%s\": [\"%s\"]," % (key, userloaddict[key])
            elif key == "enableUser" or key == "changePassOnNextLogon" or key == "passwordNeverExpires":
                AddUserPayload = AddUserPayload + "\n    \"%s\": \"%s\"," % (key, (userloaddict[key].lower()))
            else:
                AddUserPayload = AddUserPayload + "\n    \"%s\": \"%s\"," % (key, userloaddict[key])
        elif key in AddUserPayLoadColumns[13:18]:
            if not AddUserPayload.__contains__(BusinessAdd):
                AddUserPayload = AddUserPayload + BusinessAdd
            AddUserPayload = AddUserPayload + "\n     \"%s\": \"%s\","%(key,userloaddict[key])
        elif key in AddUserPayLoadColumns[18:22]:
            if not AddUserPayload.__contains__(internet):
                if AddUserPayload.__contains__(BusinessAdd):
                    AddUserPayload = AddUserPayload[:-1] + "\n     }," + internet
                else:
                    AddUserPayload = AddUserPayload + internet
            AddUserPayload = AddUserPayload + "\n     \"%s\": \"%s\"," %(key, userloaddict[key])
        elif key in AddUserPayLoadColumns[22:26]:
            if not AddUserPayload.__contains__(phone):
                if AddUserPayload.__contains__(BusinessAdd) or AddUserPayload.__contains__(internet):
                    AddUserPayload = AddUserPayload[:-1] + "\n  }," + phone
                else:
                    AddUserPayload = AddUserPayload + phone
            AddUserPayload = AddUserPayload + "\n     \"%s\": \"%s\"," % (key, userloaddict[key])
        elif key in AddUserPayLoadColumns[27:]:
            if not AddUserPayload.__contains__(personal):
                if AddUserPayload.__contains__(BusinessAdd) or AddUserPayload.__contains__(internet) or AddUserPayload.__contains__(phone):
                    AddUserPayload = AddUserPayload[:-1] + "\n  }," + personal
                else:
                    AddUserPayload = AddUserPayload  + personal
            AddUserPayload = AddUserPayload + "\n   \"%s\": \"%s\"," % (key, userloaddict[key])
    AddUserPayload = AddUserPayload[:-1] + "\n  },\n}"

    return(AddUserPayload)

# Retrieving the current user list for error checking.
SearchUserResponse = requests.request('GET', GetAddUsersUrl, timeout=60, headers=Tokenheaders, allow_redirects=False, verify=True)
GetUserJSONCount = json.loads(SearchUserResponse.text)
UserIDdict = {}

for i in GetUserJSONCount['Users']:
    UserIDdict[i['username']] = str(i["id"])
#print(UserIDdict)

# Iterate over the input data and create users in vault
with open("UserAdd_Data.csv", 'r') as data:
    for lin in data:
        line = lin.strip().split(',')
        if not lin.startswith("username,user"):
            UserPayLoad(lin)
            if userloaddict["username"] not in UserIDdict:
                CreateUserResponse = requests.request('POST', GetAddUsersUrl, timeout=60, headers=Tokenheaders, data=UserPayLoad(lin), allow_redirects=False, verify=True)
                if str(CreateUserResponse) == "<Response [200]>" or str(CreateUserResponse) == "<Response [201]>":
                    output.write("\nUser '%s' creation in Vault is \"SUCCESS\".HTTP Response: %s" % (userloaddict["username"], str(CreateUserResponse)))
                else:
                    output.write("\nUser '%s' creation in Vault \"FAILED\".HTTP Response: %s" % (userloaddict["username"], str(CreateUserResponse)))
            else:
                output.write("\nUser '%s' creation in Vault \"FAILED\". User already exists in vault."% (line[0]))

output.write("\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                                Script Execution 'END' TimeSTamp : %s - %s  \n------------------------------------------------------------------------------------------------------------------------------------------------------\n" %(today.strftime("%b-%d-%Y"), now.strftime("%H:%M:%S")))

# Logging off from Vault
LogOffresponse = requests.request('POST', LogoffUrl, timeout=30, headers=Tokenheaders, data=PayLoad, allow_redirects=False, verify=True)
output.close()