import requests
import getpass
import json
from datetime import datetime
from datetime import date

# USER TO UPDATE THE PVWA BASE ADDRESS (For E.g., cyberark.company.com)
PVWABaseURL = "pvwalb.company.com" # -- PLEASE CHANGE HERE -- #

# API URLs for the specific function, please refer the cyberark documentation for the list of URls
LogonUrl = 'https://%s/PasswordVault/API/Auth/CyberArk/Logon' % PVWABaseURL
LogoffUrl = 'https://%s/PasswordVault/API/Auth/Logoff' % PVWABaseURL
GetAddUsersUrl = 'https://%s/PasswordVault/api/Users' % PVWABaseURL

# Declaring output file for logging
output = open("UserDeletion_OutPut.txt", 'a')

now = datetime.now()
today = date.today()
output.write("\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                                Script Execution 'BEGIN' TimeSTamp : %s - %s  \n------------------------------------------------------------------------------------------------------------------------------------------------------" %(today.strftime("%b-%d-%Y"), now.strftime("%H:%M:%S")))

PayLoad = {}

# Declaring Variables for Userid & Password Prompts
userid = input("\nEnter Vault UserName: ")
passwd = getpass.getpass(prompt=('Enter (%s) Password: ') % userid)

AuthPayload = "{\r\n  \"username\":\"%s\",\r\n  \"password\":\"%s\",\n}" % (userid, passwd)
AuthHeaders = {'Content-Type': 'application/json'}

# Passing the credentials from the above declared variables to Authenticate to vault
AuthResponse = requests.request('POST', LogonUrl, headers=AuthHeaders, data=AuthPayload, allow_redirects=False, verify=True)
AuthToken = AuthResponse.text[1:-1]

# Validating Authentication using the credentials that user used.
if str(AuthResponse) != "<Response [200]>":
    print("\nAuthentication to vault is unsuccessful. Quitting!!\n")
    exit()
elif str(AuthResponse) == "<Response [200]>":
    print("\nAuthentication to vault is successful.!!\n")

# Declaring the Token header for subsequent API calls
Tokenheaders = {'Authorization': AuthToken, 'Content-Type': 'application/json', 'connection': 'keep-alive'}

# Retrieving the current user list for error checking.
SearchUserResponse = requests.request('GET', GetAddUsersUrl, timeout=60, headers=Tokenheaders, allow_redirects=False, verify=True)
GetUserJSONCount = json.loads(SearchUserResponse.text)
UserIDdict = {}

for i in GetUserJSONCount['Users']:
    UserIDdict[i['username']] = str(i["id"])
#print(UserIDdict)

# Iterate over the input data and delete users in vault
with open("UserDelete_Data.csv", 'r') as data:
    for lin in data:
        line = lin.strip()
        if not lin.startswith("username"):
            if line in UserIDdict:
                DeleteUserResponse = requests.request('DELETE', (GetAddUsersUrl + "/" + str(UserIDdict[line]) + "/"), timeout=60, headers=Tokenheaders, allow_redirects=False, verify=True)
                if str(DeleteUserResponse) == "<Response [200]>" or str(DeleteUserResponse) == "<Response [204]>":
                    output.write("\nUser '%s' deletion in Vault is \"SUCCESS\".HTTP Response: %s" % (line, str(DeleteUserResponse)))
                else:
                    output.write("\nUser '%s' deletion in Vault \"FAILED\".HTTP Response: %s" % (line, str(DeleteUserResponse)))
            else:
                output.write("\nUser '%s' deletion in Vault \"FAILED\". User does not exists in vault."% line)

output.write("\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                                Script Execution 'END' TimeSTamp : %s - %s  \n------------------------------------------------------------------------------------------------------------------------------------------------------\n" %(today.strftime("%b-%d-%Y"), now.strftime("%H:%M:%S")))

# Logging off from Vault
LogOffresponse = requests.request('POST', LogoffUrl, timeout=30, headers=Tokenheaders, data=PayLoad, allow_redirects=False, verify=True)
output.close()