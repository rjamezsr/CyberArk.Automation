import requests
import getpass
import json
from datetime import datetime
from datetime import date

# USER TO UPDATE THE PVWA BASE ADDRESS (For E.g., cyberark.company.com)
PVWABaseURL = "pvwa.company.com" # -- ENTER THE BASE URL WITHOUT HTTPS://-- #

# API URLs for the specific function, please refer the cyberark documentation for the list of URls

LogonUrl = 'https://%s/PasswordVault/API/Auth/CyberArk/Logon' % PVWABaseURL
LogoffUrl = 'https://%s/PasswordVault/API/Auth/Logoff' % PVWABaseURL
GetUsers = 'https://%s/PasswordVault/api/Users' % PVWABaseURL

now = datetime.now()
today = date.today()

# InputFile = "RemoveUser_from_Group_Data.csv"
UserOutput = open("User_LastLogon_Output%s_%s.txt" % (today.strftime("%b-%d-%Y"), now.strftime("%H-%M-%S")), 'w')
UserOutput.write("UserID,FirstName,LastName,Title,Department,Email,LastLoggedInDate,LastLogonInDays"+"\n\n")

PayLoad = {}

# Declaring Variables for Userid & Password Prompts
userid = input("\nEnter Vault UserName: ")
passwd = getpass.getpass(prompt=('Enter (%s) Password: ') % userid)

AuthPayload = "{\r\n  \"username\":\"%s\",\r\n  \"password\":\"%s\",\n}" % (userid, passwd)
AuthHeaders = {'Content-Type': 'application/json'}

# Passing the credentials from the above declared variables to Authenticate to vault
AuthResponse = requests.request('POST', LogonUrl, headers=AuthHeaders, data=AuthPayload, allow_redirects=False, verify=True, timeout=15)
AuthToken = AuthResponse.text[1:-1]

# Validating Authentication using the credentials that user used.
if str(AuthResponse) != "<Response [200]>":
    print(AuthResponse.text)
    print("\nAuthentication to vault is unsuccessful. Quitting!!\n")
    exit()
elif str(AuthResponse) == "<Response [200]>":
    print("\nAuthentication to vault is successful.!!\n")

# Declaring the Token header for subsequent API calls
Tokenheaders = {'Authorization': AuthToken, 'Content-Type': 'application/json', 'connection': 'keep-alive'}

# Retrieving the current group list for error checking.
SearchUserResponse = requests.request('GET', GetUsers, timeout=60, headers=Tokenheaders, allow_redirects=False, verify=True)
GetUserJSONCount = json.loads(SearchUserResponse.text)
#print(GetUserJSONCount)

# Retrieving the current user's list for getting the id.
GetUserDetails = requests.request('GET', GetUsers + "/", timeout=60, headers=Tokenheaders, allow_redirects=False, verify=True)
UserDetailJSONCount = {}

count = 0

for i in GetUserJSONCount['Users']:
    value = ""
    if i['userType'] == 'EPVUser':
        value = value + i['username']
        GetUserDetails = requests.request('GET', (GetUsers + "/" + str(i['id'])), timeout=60, headers=Tokenheaders, allow_redirects=False, verify=True)
        UserDetailJSONCount = json.loads(GetUserDetails.text)

        login = int(UserDetailJSONCount['lastSuccessfulLoginDate'])

        lastlogin = str((datetime.utcfromtimestamp(login).strftime('%Y-%m-%d %H:%M:%S')))

        todayDate = datetime.strptime(str(today), '%Y-%m-%d')
        userlastLoginDate = datetime.strptime(str(lastlogin[:10]), '%Y-%m-%d')

        lastLogin_inDays = todayDate.date() - userlastLoginDate.date()
        lastLoginPeriod = str(lastLogin_inDays)[:-14]

        title = str(UserDetailJSONCount['personalDetails']['title']).replace(",", "")
        department = str(UserDetailJSONCount['personalDetails']['department']).replace(",", "")

        value = value + "," + str(UserDetailJSONCount['personalDetails']['firstName']) + "," + str(UserDetailJSONCount['personalDetails']['lastName']) + "," + title + "," + department + "," + str(UserDetailJSONCount['internet']['businessEmail']) + "," + lastlogin + "," + lastLoginPeriod + "\n"

        print(value)
        UserOutput.write(str(value))


# Logging off from Vault
LogOffresponse = requests.request('POST', LogoffUrl, timeout=30, headers=Tokenheaders, data=PayLoad, allow_redirects=False, verify=True)
