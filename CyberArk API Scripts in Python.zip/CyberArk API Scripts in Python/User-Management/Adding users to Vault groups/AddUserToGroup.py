import requests
import getpass
import json
from datetime import datetime
from datetime import date

# USER TO UPDATE THE PVWA BASE ADDRESS (For E.g., cyberark.company.com)
PVWABaseURL = "pvwalb.company.com" # -- PLEASE CHANGE HERE -- #

# API URLs for the specific function, please refer the cyberark documentation for the list of URls
LogonUrl = 'https://%s/PasswordVault/API/Auth/CyberArk/Logon' % PVWABaseURL
LogoffUrl = 'https://%s/PasswordVault/API/Auth/Logoff' % PVWABaseURL
GetAddGroupsUrl = 'https://%s/PasswordVault/api/UserGroups' % PVWABaseURL
GetAddUsersUrl = 'https://%s/PasswordVault/api/Users' % PVWABaseURL

# Declaring output file for logging
output = open("AddUserToGroup_OutPut.txt", 'a')

now = datetime.now()
today = date.today()
output.write("\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                                Script Execution 'BEGIN' TimeSTamp : %s - %s  \n------------------------------------------------------------------------------------------------------------------------------------------------------" %(today.strftime("%b-%d-%Y"), now.strftime("%H:%M:%S")))

PayLoad = {}

# Declaring Variables for Userid & Password Prompts
userid = input("\nEnter Vault UserName: ")
passwd = getpass.getpass(prompt=('Enter (%s) Password: ') % userid)

AuthPayload = "{\r\n  \"username\":\"%s\",\r\n  \"password\":\"%s\",\n}" % (userid, passwd)
AuthHeaders = {'Content-Type': 'application/json'}

# Passing the credentials from the above declared variables to Authenticate to vault
AuthResponse = requests.request('POST', LogonUrl, headers=AuthHeaders, data=AuthPayload, allow_redirects=False, verify=True)
AuthToken = AuthResponse.text[1:-1]

# Validating Authentication using the credentials that user used.
if str(AuthResponse) != "<Response [200]>":
    print("\nAuthentication to vault is unsuccessful. Quitting!!\n")
    exit()
elif str(AuthResponse) == "<Response [200]>":
    print("\nAuthentication to vault is successful.!!\n")

# Declaring the Token header for subsequent API calls
Tokenheaders = {'Authorization': AuthToken, 'Content-Type': 'application/json', 'connection': 'keep-alive'}

# Retrieving the current group list for error checking.
SearchGroupResponse = requests.request('GET', GetAddGroupsUrl, timeout=60, headers=Tokenheaders, allow_redirects=False, verify=True)
GetGroupJSONCount = json.loads(SearchGroupResponse.text)
GroupIDdict = {}

for i in GetGroupJSONCount['value']:
    GroupIDdict[i['groupName']] = str(i["id"]), (i['groupType'])
#print(GroupIDdict)

# Iterate over the input data and add users to Vault groups
with open("AddUser_to_Group_Data.csv", 'r') as data:
    for lin in data:
        line = lin.strip().split(',')
        if not lin.startswith("groupName"):
            if not line[0] in GroupIDdict:
                #createGroupPayload = "{\n    \"groupName\": %s,\n    \"description\": %s,\n    \"location\": \"\\\\\"\n}" %(line[0],line[2])
                output.write("\nGroup '%s' does not exists in vault. Validate the group name and create the group manually and retry."% line[0])
            elif line[0] in GroupIDdict:
                memberPayload = "{\n\"memberId\": \"%s\",\n\"memberType\": \"vault\"\n}" %(line[1])
                AddUserToGroupResponse = requests.request('POST', (GetAddGroupsUrl + "/" + str(GroupIDdict[(line[0])][0]) + "/Members"), timeout=60, data=memberPayload, headers=Tokenheaders, allow_redirects=False, verify=True)
                print ((GetAddGroupsUrl + "/" + str(GroupIDdict[(line[0])][0])))
                if str(AddUserToGroupResponse) == "<Response [200]>" or str(AddUserToGroupResponse) == "<Response [201]>":
                    output.write("\nUser '%s' addition to the vault group '%s' is \"SUCCESS\".HTTP Response: %s" % (line[1], line[0], str(AddUserToGroupResponse)))
                else:
                    output.write("\nUser '%s' addition to the vault group '%s' \"FAILED\".HTTP Response: %s" % (line[1], line[0], str(AddUserToGroupResponse)))

output.write("\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                                Script Execution 'END' TimeSTamp : %s - %s  \n------------------------------------------------------------------------------------------------------------------------------------------------------\n" %(today.strftime("%b-%d-%Y"), now.strftime("%H:%M:%S")))

# Logging off from Vault
LogOffresponse = requests.request('POST', LogoffUrl, timeout=30, headers=Tokenheaders, data=PayLoad, allow_redirects=False, verify=True)
output.close()