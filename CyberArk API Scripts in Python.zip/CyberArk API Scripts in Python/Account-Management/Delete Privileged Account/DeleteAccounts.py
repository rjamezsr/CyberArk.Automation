import requests
import getpass
import json
from datetime import datetime
from datetime import date

# USER TO UPDATE THE PVWA BASE ADDRESS (For E.g., cyberark.company.com)
PVWABaseURL = "pvwalb.company.com" # -- PLEASE CHANGE HERE -- #

# API URLs for the specific function, please refer the cyberark documentation for the list of URls

LogonUrl = 'https://%s/PasswordVault/API/Auth/CyberArk/logon' % PVWABaseURL
AddAccountUrl = "https://%s/PasswordVault/api/Accounts" % PVWABaseURL
SafeCreationUrl = 'https://%s/PasswordVault/WebServices/PIMServices.svc/Safes' % PVWABaseURL
AddSafeMemberUrl = 'https://%s/PasswordVault/WebServices/PIMServices.svc/Safes/Members' % PVWABaseURL
GetAccountUrl = 'https://%s/PasswordVault/api/Accounts?&search=' % PVWABaseURL
Logoffurl = 'https://%s/PasswordVault/API/Auth/Logoff' % PVWABaseURL

# Initializing the output for the logging
output = open("DeleteAccounts_Output.txt", 'a')

now = datetime.now()
today = date.today()
output.write("\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                                Script Execution 'BEGIN' TimeSTamp : %s - %s  \n\n" %(today.strftime("%b-%d-%Y"), now.strftime("%H:%M:%S")))

PayLoad = {}

# Declaring Variables for Userid & Password Prompts
userid = input("\nEnter Vault UserName: ")
passwd = getpass.getpass(prompt=('Enter (%s) Password: ') % userid)

AuthPayload = "{\r\n  \"username\":\"%s\",\r\n  \"password\":\"%s\",\n}" % (userid, passwd)
AuthHeaders = {'Content-Type': 'application/json'}

# Passing the credentials from the above declared variables to Authenticate to vault
AuthResponse = requests.request('POST', LogonUrl, headers=AuthHeaders, data=AuthPayload, allow_redirects=False, verify=True)
AuthToken = AuthResponse.text[1:-1]

# Validating Authentication using the credentials that user used.
if str(AuthResponse) != "<Response [200]>":
    print("\nAuthentication to vault is unsuccessful. Quitting!!\n")
    exit()
elif str(AuthResponse) == "<Response [200]>":
    print("\nAuthentication to vault is successful.!!\n")

# Declaring the Token header for subsequent API calls
Tokenheaders = {'Authorization': AuthToken, 'Content-Type': 'application/json', 'connection': 'keep-alive'}

with open("DeleteAccounts_Data.csv", 'r') as data:
    ColnHeader = list(next(data).split(','))
    ColnHeader = [colns.strip() for colns in ColnHeader]


# FUNCTION THAT VALIDATES WHETHER THE ACCOUNT EXISTS IN VAULT, and RETRIEVES THE ACCOUNT-ID PARAMETER REQUIRED FOR DELETING.
def DelAcct(line):
    line = line.strip()
    value = line.split(',')
    DelAcct.AcctDatadict = {}
    AddAccountPayLoadColumns = ["name", "DeviceType", "address", "userName", "credentialtype", "platformId", "safeName", "secretType", "secret", "Desc","Region", "PropertyName", "PropertyAddress", "UnitNo", "HostName", "Port", "WebPort"]

    for colns in ColnHeader:
        index = ColnHeader.index(colns)
        if colns in AddAccountPayLoadColumns:
            DelAcct.AcctDatadict[colns] = value[index]

    URL = (GetAccountUrl + "%s" + " " + "%s" + " " + "%s" + " " + "%s") % (DelAcct.AcctDatadict['DeviceType'], DelAcct.AcctDatadict['platformId'], DelAcct.AcctDatadict['address'], DelAcct.AcctDatadict['userName'])
    SearchAccountResponse = requests.request('GET', URL, timeout=30, headers=Tokenheaders, data=PayLoad, allow_redirects=False, verify=True) #% (DelAcct.AcctDatadict['DeviceType'], DelAcct.AcctDatadict['platformId'], DelAcct.AcctDatadict['address'], DelAcct.AcctDatadict['userName'])
    SearchAccountJSONCount = json.loads(SearchAccountResponse.text)

    if (SearchAccountJSONCount["count"]) > 0:
        addList = []
        nameList = []
        for address in SearchAccountJSONCount['value']:
            addList.append(address['address'])
        for name in SearchAccountJSONCount['value']:
            nameList.append(name['name'])
        for id in SearchAccountJSONCount['value']:
            if (DelAcct.AcctDatadict['address']) == id['address'] and (DelAcct.AcctDatadict['name']) == id['name']:
                    return (id['id'])

    elif (SearchAccountJSONCount["count"]) == 0:
        output.write("\nThe account '%s' with address '%s' deletion failed. The Account does not exist in vault." % (DelAcct.AcctDatadict['userName'], DelAcct.AcctDatadict['address']))


with open('DeleteAccounts_Data.csv') as DelInputData:
    for lin in DelInputData:
        if not lin.startswith("name,DeviceType"):
            line = lin.strip().split(',')
            Delpayload = "{\"reason\":\"MACD Device Decommission\"}"

# USE THE ACCOUNT-ID RECEIVED FROM THE ABOVE STEP AND INITIATE THE DELETION PROCESS
            id = DelAcct(lin)
            DelAcctResponse = requests.request('DELETE', (AddAccountUrl + "/" + str(id)), timeout=30, data=Delpayload, headers=Tokenheaders, allow_redirects=False, verify=True)
            if str(DelAcctResponse) == "<Response [204]>":
                output.write("\nAccount deleted Successfully. The API Response for DELETING account - \'%s\' in Safe - \'%s\' for the Address - \'%s\' is  %s ." % (line[0], line[2], line[1], str(DelAcctResponse)))
            elif str(DelAcctResponse) != "<Response [204]>":
                output.write("\nAccount NOT deleted.The API Response for DELETING account - \'%s\' in Safe - \'%s\' for the Address - \'%s\' is  %s." % (line[0], line[2], line[1], str(DelAcctResponse)))


output.write("\n\n                                Script Execution 'END' TimeStamp : %s - %s  \n------------------------------------------------------------------------------------------------------------------------------------------------------\n\n\n" %(today.strftime("%b-%d-%Y"), now.strftime("%H:%M:%S")))

# LOGOFF FROM VAULT AFTER THE REQUIRED ADMIN TASKS ARE COMPLETE
LogOffresponse = requests.request('POST', Logoffurl, timeout=30, headers=Tokenheaders, data=PayLoad, allow_redirects=False, verify=True)
output.close()
