import requests
import getpass
import json
from datetime import datetime
from datetime import date

# USER TO UPDATE THE PVWA BASE ADDRESS (For E.g., cyberark.company.com)
PVWABaseURL = "pvwalb.company.com" # -- PLEASE CHANGE HERE -- #

# API URLs for the specific function, please refer the cyberark documentation for the list of URls

LogonUrl = 'https://%s/PasswordVault/API/Auth/CyberArk/logon' % PVWABaseURL
AddAccountUrl = "https://%s/PasswordVault/api/Accounts" % PVWABaseURL
SafeCreationUrl = 'https://%s/PasswordVault/WebServices/PIMServices.svc/Safes' % PVWABaseURL
AddSafeMemberUrl = 'https://%s/PasswordVault/WebServices/PIMServices.svc/Safes/Members' % PVWABaseURL
GetAccountUrl = 'https://%s/PasswordVault/api/Accounts?&search=' % PVWABaseURL
Logoffurl = 'https://%s/PasswordVault/API/Auth/Logoff' % PVWABaseURL

# Initializing the output for the logging
output = open("Addaccount-Output.txt", 'a')

now = datetime.now()
today = date.today()
output.write("\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                                Script Execution 'BEGIN' TimeSTamp : %s - %s  \n\n" %(today.strftime("%b-%d-%Y"), now.strftime("%H:%M:%S")))

PayLoad = {}

# Declaring Variables for Userid & Password Prompts
userid = input("\nEnter Vault UserName: ")
passwd = getpass.getpass(prompt=('Enter (%s) Password: ') % userid)

AuthPayload = "{\r\n  \"username\":\"%s\",\r\n  \"password\":\"%s\",\n}" % (userid, passwd)
AuthHeaders = {'Content-Type': 'application/json'}

# Passing the credentials from the above declared variables to Authenticate to vault
AuthResponse = requests.request('POST', LogonUrl, headers=AuthHeaders, data=AuthPayload, allow_redirects=False, verify=True)
AuthToken = AuthResponse.text[1:-1]

# Validating Authentication using the credentials that user used.
if str(AuthResponse) != "<Response [200]>":
    print("\nAuthentication to vault is unsuccessful. Quitting!!\n")
    exit()
elif str(AuthResponse) == "<Response [200]>":
    print("\nAuthentication to vault is successful.!!\n")

# Declaring the Token header for subsequent API calls
Tokenheaders = {'Authorization': AuthToken, 'Content-Type': 'application/json', 'connection': 'keep-alive'}

with open("Addaccount-Data.csv", 'r') as data:
    ColnHeader = list(next(data).split(','))
    ColnHeader = [colns.strip() for colns in ColnHeader]

#Function to serialize and format the JSON payload needed for user creation.

def PortSearch():

    if str(AccountPayLoad.AcctDatadict['Port']) != "" and str(AccountPayLoad.AcctDatadict['WebPort']) == "":
        URL = (GetAccountUrl + "%s" + " " + "%s" + " " + "%s" + " " + "%s" + " " + "%s") % (AccountPayLoad.AcctDatadict['DeviceType'], AccountPayLoad.AcctDatadict['platformId'], AccountPayLoad.AcctDatadict['address'], AccountPayLoad.AcctDatadict['userName'], AccountPayLoad.AcctDatadict['Port'])
        SearchAccountWithPortResponse = requests.request('GET', URL, timeout=30, headers=Tokenheaders, data=PayLoad, allow_redirects=False, verify=True) #% (AccountPayLoad.AcctDatadict['DeviceType'], AccountPayLoad.AcctDatadict['platformId'], AccountPayLoad.AcctDatadict['address'], AccountPayLoad.AcctDatadict['userName'], AccountPayLoad.AcctDatadict['Port'])
        SearchAccountWIthPortJSONCount = json.loads(SearchAccountWithPortResponse.text)

        OnbPayload = "{\n\t\"name\": \"%s\",\n\t\"address\": \"%s\",\n\t\"userName\": \"%s\",\n\t\"platformId\": \"%s\",\n\t\"safeName\": \"%s\",\n\t\"secretType\": \"password\",\n\t\"secret\": \"%s\",\n\t\"platformAccountProperties\": {" % (
        (AccountPayLoad.AcctDatadict['name'] + "-" + AccountPayLoad.AcctDatadict['Port']), AccountPayLoad.AcctDatadict['address'], AccountPayLoad.AcctDatadict['userName'], AccountPayLoad.AcctDatadict['platformId'], AccountPayLoad.AcctDatadict['safeName'], AccountPayLoad.AcctDatadict['secret'])

        if SearchAccountWIthPortJSONCount["count"] == 0 and  AccountPayLoad.AcctDatadict['address'] not in SearchAccountWIthPortJSONCount['value']:
            for item in AccountPayLoad.AddAccountPayLoadColumns[8:]:
                if item in AccountPayLoad.AcctDatadict and (AccountPayLoad.AcctDatadict)[item] != "":
                    OnbPayload = OnbPayload + "\n\t\t\"%s\": \"%s\"," % (item, (AccountPayLoad.AcctDatadict)[item])
            OnbPayload = OnbPayload[:-1] + "\n\t}\n}"
            return OnbPayload
        else:
            output.write("\nThe account '%s' with address '%s' onboard to vault FAILED. One of the possible reasons is the account already exists" % (AccountPayLoad.AcctDatadict['userName'], AccountPayLoad.AcctDatadict['address']))
            return None

    elif str(AccountPayLoad.AcctDatadict['Port']) == "" and str(AccountPayLoad.AcctDatadict['WebPort']) != "":
        URL = (GetAccountUrl + "%s" + " " + "%s" + " " + "%s" + " " + "%s" + " " + "%s") % (AccountPayLoad.AcctDatadict['DeviceType'], AccountPayLoad.AcctDatadict['platformId'], AccountPayLoad.AcctDatadict['address'], AccountPayLoad.AcctDatadict['userName'], AccountPayLoad.AcctDatadict['WebPort'])
        SearchAccountWithPortResponse = requests.request('GET', URL, timeout=30, headers=Tokenheaders, data=PayLoad, allow_redirects=False, verify=True)
        SearchAccountWIthPortJSONCount = json.loads(SearchAccountWithPortResponse.text)

        OnbPayload = "{\n\t\"name\": \"%s\",\n\t\"address\": \"%s\",\n\t\"userName\": \"%s\",\n\t\"platformId\": \"%s\",\n\t\"safeName\": \"%s\",\n\t\"secretType\": \"password\",\n\t\"secret\": \"%s\",\n\t\"platformAccountProperties\": {" % (
        (AccountPayLoad.AcctDatadict['name'] + "-" + AccountPayLoad.AcctDatadict['WebPort']), AccountPayLoad.AcctDatadict['address'], AccountPayLoad.AcctDatadict['userName'], AccountPayLoad.AcctDatadict['platformId'], AccountPayLoad.AcctDatadict['safeName'], AccountPayLoad.AcctDatadict['secret'])

        if SearchAccountWIthPortJSONCount["count"] == 0 and  AccountPayLoad.AcctDatadict['address'] not in SearchAccountWIthPortJSONCount['value']:
            for item in AccountPayLoad.AddAccountPayLoadColumns[8:]:
                if item in AccountPayLoad.AcctDatadict and (AccountPayLoad.AcctDatadict)[item] != "":
                    OnbPayload = OnbPayload + "\n\t\t\"%s\": \"%s\"," % (item, (AccountPayLoad.AcctDatadict)[item])
            OnbPayload = OnbPayload[:-1] + "\n\t}\n}"
            return OnbPayload
        else:
            output.write("\nThe account '%s' with address '%s' onboard to vault FAILED. One of the possible reasons is the account already exists" % (AccountPayLoad.AcctDatadict['userName'], AccountPayLoad.AcctDatadict['address']))
            return None

    elif str(AccountPayLoad.AcctDatadict['Port']) != "" and str(AccountPayLoad.AcctDatadict['WebPort']) != "":
        URL = (GetAccountUrl + "%s" + " " + "%s" + " " + "%s" + " " + "%s" + " " + "%s" + " " + "%s") %(AccountPayLoad.AcctDatadict['DeviceType'], AccountPayLoad.AcctDatadict['platformId'], AccountPayLoad.AcctDatadict['address'], AccountPayLoad.AcctDatadict['userName'], AccountPayLoad.AcctDatadict['Port'], AccountPayLoad.AcctDatadict['WebPort'])
        SearchAccountWithPortResponse = requests.request('GET', URL, timeout=30, headers=Tokenheaders, data=PayLoad, allow_redirects=False, verify=True) #%(AccountPayLoad.AcctDatadict['DeviceType'], AccountPayLoad.AcctDatadict['platformId'], AccountPayLoad.AcctDatadict['address'], AccountPayLoad.AcctDatadict['userName'], AccountPayLoad.AcctDatadict['WebPort'])
        SearchAccountWIthPortJSONCount = json.loads(SearchAccountWithPortResponse.text)
        AccountPayLoad.AcctDatadict['name'] = AccountPayLoad.AcctDatadict['name'] + "-" + AccountPayLoad.AcctDatadict['Port'] + "-" + AccountPayLoad.AcctDatadict['WebPort']

        OnbPayload = "{\n\t\"name\": \"%s\",\n\t\"address\": \"%s\",\n\t\"userName\": \"%s\",\n\t\"platformId\": \"%s\",\n\t\"safeName\": \"%s\",\n\t\"secretType\": \"password\",\n\t\"secret\": \"%s\",\n\t\"platformAccountProperties\": {" % (
        (AccountPayLoad.AcctDatadict['name'] + "-" + AccountPayLoad.AcctDatadict['Port'] + "-" + AccountPayLoad.AcctDatadict['WebPort']), AccountPayLoad.AcctDatadict['address'], AccountPayLoad.AcctDatadict['userName'], AccountPayLoad.AcctDatadict['platformId'], AccountPayLoad.AcctDatadict['safeName'], AccountPayLoad.AcctDatadict['secret'])

        if SearchAccountWIthPortJSONCount["count"] == 0 and  AccountPayLoad.AcctDatadict['address'] not in SearchAccountWIthPortJSONCount['value']:
            for item in AccountPayLoad.AddAccountPayLoadColumns[8:]:
                if item in AccountPayLoad.AcctDatadict and (AccountPayLoad.AcctDatadict)[item] != "":
                    OnbPayload = OnbPayload + "\n\t\t\"%s\": \"%s\"," % (item, (AccountPayLoad.AcctDatadict)[item])
            OnbPayload = OnbPayload[:-1] + "\n\t}\n}"
            return OnbPayload

    else:
        output.write("\nThe account '%s' with address '%s' onboard to vault FAILED. One of the possible reasons is the account already exists" %(AccountPayLoad.AcctDatadict['userName'], AccountPayLoad.AcctDatadict['address']))
        return None

def AccountSearch():

    OnbPayload = "{\n\t\"name\": \"%s\",\n\t\"address\": \"%s\",\n\t\"userName\": \"%s\",\n\t\"platformId\": \"%s\",\n\t\"safeName\": \"%s\",\n\t\"secretType\": \"password\",\n\t\"secret\": \"%s\",\n\t\"platformAccountProperties\": {" % (AccountPayLoad.AcctDatadict['name'], AccountPayLoad.AcctDatadict['address'], AccountPayLoad.AcctDatadict['userName'], AccountPayLoad.AcctDatadict['platformId'], AccountPayLoad.AcctDatadict['safeName'], AccountPayLoad.AcctDatadict['secret'])

    for item in AccountPayLoad.AddAccountPayLoadColumns[8:]:
        if item in AccountPayLoad.AcctDatadict and (AccountPayLoad.AcctDatadict)[item] != "":
            OnbPayload = OnbPayload + "\n\t\t\"%s\": \"%s\"," % (item, (AccountPayLoad.AcctDatadict)[item])
    OnbPayload = OnbPayload[:-1] + "\n\t}\n}"

    return OnbPayload


def AccountPayLoad(line):
    line = line.strip()
    value = line.split(',')
    AccountPayLoad.AcctDatadict = {}
    AccountPayLoad.AddAccountPayLoadColumns = ["name", "DeviceType", "address", "userName", "platformId", "safeName", "secretType", "secret", "credentialtype","Desc","Region", "PropertyName", "PropertyAddress", "UnitNo", "HostName", "Port", "WebPort"]

    for colns in ColnHeader:
        index = ColnHeader.index(colns)
        if colns in AccountPayLoad.AddAccountPayLoadColumns:
            AccountPayLoad.AcctDatadict[colns] = value[index]

    URL = (GetAccountUrl + "%s" + " " + "%s" + " " + "%s" + " " + "%s") % (AccountPayLoad.AcctDatadict['DeviceType'], AccountPayLoad.AcctDatadict['platformId'], AccountPayLoad.AcctDatadict['address'], AccountPayLoad.AcctDatadict['userName'])
    AccountPayLoad.SearchAccountResponse = requests.request('GET', URL, timeout=30, headers=Tokenheaders, data=PayLoad, allow_redirects=False, verify=True) #% (AccountPayLoad.AcctDatadict['DeviceType'], AccountPayLoad.AcctDatadict['platformId'], AccountPayLoad.AcctDatadict['address'], AccountPayLoad.AcctDatadict['userName'])
    AccountPayLoad.SearchAccountJSONCount = json.loads((AccountPayLoad.SearchAccountResponse).text)

    if (AccountPayLoad.SearchAccountJSONCount["count"]) > 0:
        addList = []
        for address in AccountPayLoad.SearchAccountJSONCount['value']:
            addList.append(address['address'])
        if (AccountPayLoad.AcctDatadict['address']) not in addList:
            return AccountSearch()
        elif (AccountPayLoad.AcctDatadict['address']) in addList:
            return PortSearch()

    elif (AccountPayLoad.SearchAccountJSONCount["count"]) == 0:
        return AccountSearch()


with open('Addaccount-Data.csv', 'r') as AddAcctInputData:
    for lin in AddAcctInputData:
        if not lin.startswith("name,DeviceType"):
            payload = AccountPayLoad(lin)
            AddAcctResponse = requests.request('POST', AddAccountUrl, timeout=30, headers=Tokenheaders, data=payload, allow_redirects=False, verify=True)
            print(payload)
            if str(AddAcctResponse) == "<Response [200]>" or str(AddAcctResponse ) == "<Response [201]>":
                output.write("\nThe account '%s' on '%s' has been successfully onboarded to vault. HTTP Response: %s" % (AccountPayLoad.AcctDatadict['userName'], AccountPayLoad.AcctDatadict['address'], str(AddAcctResponse)))
            else:
                output.write("\nThe account '%s' onboard to vault FAILED. HTTP Response: %s" %(AccountPayLoad.AcctDatadict['userName'], str(AddAcctResponse)))

output.write("\n\n                                Script Execution 'END' TimeStamp : %s - %s  \n------------------------------------------------------------------------------------------------------------------------------------------------------\n\n\n" %(today.strftime("%b-%d-%Y"), now.strftime("%H:%M:%S")))

LogOffresponse = requests.request('POST', Logoffurl, timeout=30, headers=Tokenheaders, data=PayLoad, allow_redirects=False, verify=True)
output.close()