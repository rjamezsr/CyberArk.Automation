import requests
import getpass
import json
from datetime import datetime
from datetime import date

# USER TO UPDATE THE PVWA BASE ADDRESS (For E.g., cyberark.company.com)
PVWABaseURL = "pvwalb.company.com" # -- PLEASE CHANGE HERE -- #

# API URLs for the specific function, please refer the cyberark documentation for the list of URls

LogonUrl = 'https://%s/PasswordVault/API/Auth/CyberArk/logon' % PVWABaseURL
AddAccountUrl = "https://%s/PasswordVault/api/Accounts" % PVWABaseURL
SafeCreationUrl = 'https://%s/PasswordVault/WebServices/PIMServices.svc/Safes' % PVWABaseURL
AddSafeMemberUrl = 'https://%s/PasswordVault/WebServices/PIMServices.svc/Safes/Members' % PVWABaseURL
GetAccountUrl = 'https://%s/PasswordVault/api/Accounts?&search=' % PVWABaseURL
Logoffurl = 'https://%s/PasswordVault/API/Auth/Logoff' % PVWABaseURL

# Initializing the output for the logging
output = open("MoveAccounts_Output.txt", 'a')

now = datetime.now()
today = date.today()
output.write("\n------------------------------------------------------------------------------------------------------------------------------------------------------\n                                Script Execution 'BEGIN' TimeSTamp : %s - %s  \n\n" %(today.strftime("%b-%d-%Y"), now.strftime("%H:%M:%S")))

PayLoad = {}

# Declaring Variables for Userid & Password Prompts
userid = input("\nEnter Vault UserName: ")
passwd = getpass.getpass(prompt=('Enter (%s) Password: ') % userid)

AuthPayload = "{\r\n  \"username\":\"%s\",\r\n  \"password\":\"%s\",\n}" % (userid, passwd)
AuthHeaders = {'Content-Type': 'application/json'}

# Passing the credentials from the above declared variables to Authenticate to vault
AuthResponse = requests.request('POST', LogonUrl, headers=AuthHeaders, data=AuthPayload, allow_redirects=False, verify=True)
AuthToken = AuthResponse.text[1:-1]

# Validating Authentication using the credentials that user used.
if str(AuthResponse) != "<Response [200]>":
    print("\nAuthentication to vault is unsuccessful. Quitting!!\n")
    exit()
elif str(AuthResponse) == "<Response [200]>":
    print("\nAuthentication to vault is successful.!!\n")

# Declaring the Token header for subsequent API calls
Tokenheaders = {'Authorization': AuthToken, 'Content-Type': 'application/json', 'connection': 'keep-alive'}

with open("MoveAccounts_Data.csv", 'r') as data:
    ColnHeader = list(next(data).split(','))
    ColnHeader = [colns.strip() for colns in ColnHeader]

# FUNCTION THAT VALIDATES WHETHER THE ACCOUNT EXISTS IN VAULT, and RETRIEVES THE ACCOUNT-ID PARAMETER REQUIRED FOR DELETING.
def MoveAcct(line):
    line = line.strip()
    value = line.split(',')
    MoveAcct.AcctDatadict = {}
    PayLoadColumns = ["name", "DeviceType", "address", "userName", "platformId", "safeName", "NewSafename"]

    for colns in ColnHeader:
        index = ColnHeader.index(colns)
        if colns in PayLoadColumns:
            MoveAcct.AcctDatadict[colns] = value[index]

    URL = (GetAccountUrl + "%s" + " " + "%s" + " " + "%s" + " " + "%s") % (MoveAcct.AcctDatadict['DeviceType'], MoveAcct.AcctDatadict['platformId'], MoveAcct.AcctDatadict['address'], MoveAcct.AcctDatadict['userName'])

    SearchAccountResponse = requests.request('GET', URL, timeout=30, headers=Tokenheaders, data=PayLoad, allow_redirects=False, verify=True) #% (MoveAcct.AcctDatadict['DeviceType'], MoveAcct.AcctDatadict['platformId'], MoveAcct.AcctDatadict['address'], MoveAcct.AcctDatadict['userName'])
    SearchAccountJSONCount = json.loads(SearchAccountResponse.text)

    if (SearchAccountJSONCount["count"]) > 0:
        addList = []
        nameList = []
        for address in SearchAccountJSONCount['value']:
            addList.append(address['address'])
        for name in SearchAccountJSONCount['value']:
            nameList.append(name['name'])
        for id in SearchAccountJSONCount['value']:
            if (MoveAcct.AcctDatadict['address']) == id['address'] and (MoveAcct.AcctDatadict['name']) == id['name']:
                return (id['id'])

    elif (SearchAccountJSONCount["count"]) == 0:
        output.write("\nThe account '%s' with address '%s' deletion failed. The Account does not exist in vault." % (MoveAcct.AcctDatadict['userName'], MoveAcct.AcctDatadict['address']))


with open('MoveAccounts_Data.csv') as MoveInputData:
    for lin in MoveInputData:
        if not lin.startswith("name,DeviceType"):
            Delpayload = "{\"reason\":\"MACD Device Decommission\"}"
            id = MoveAcct(lin)

            RetrieveCred = requests.request('POST', (AddAccountUrl + "/" + str(id) + "/Password/Retrieve"), timeout=30, headers=Tokenheaders, allow_redirects=False, verify=True)
            RetrievePayload = requests.request('GET', (AddAccountUrl + "/" + str(id)), timeout=30, headers=Tokenheaders, allow_redirects=False, verify=True)
            AddAccountJSONCount = json.loads(RetrievePayload.text)

            output.write("\nThe API Response for retrieving account - \'%s\' credentials in Safe - \'%s\' for the Address - \'%s\' is < %s >" % (MoveAcct.AcctDatadict['userName'], MoveAcct.AcctDatadict['safeName'], MoveAcct.AcctDatadict['address'], str(RetrieveCred)))

            OnbPayload = "{\n\t\"name\": \"%s\",\n\t\"address\": \"%s\",\n\t\"userName\": \"%s\",\n\t\"platformId\": \"%s\",\n\t\"safeName\": \"%s\",\n\t\"secretType\": \"password\",\n\t\"secret\": %s," % (AddAccountJSONCount['name'], AddAccountJSONCount['address'], AddAccountJSONCount['userName'], AddAccountJSONCount['platformId'], MoveAcct.AcctDatadict['NewSafename'], (RetrieveCred.text))

            if ("platformAccountProperties") in RetrievePayload.json():
                OnbPayload = OnbPayload + "\n\t\"platformAccountProperties\": {"
                for item in (AddAccountJSONCount['platformAccountProperties']):
                    OnbPayload = OnbPayload + "\n\t\t\"%s\": \"%s\"," % (item, AddAccountJSONCount['platformAccountProperties'][item])
                OnbPayload = OnbPayload[:-1] + "\n\t}\n}"
                # print (OnbPayload)
            elif not ("platformAccountProperties") in RetrievePayload.json():
                OnbPayload = OnbPayload[:-1] + "\n}"
                # print(OnbPayload)

            MoveAcctResponse = requests.request('DELETE', (AddAccountUrl + "/" + str(id)), timeout=30, data=Delpayload, headers=Tokenheaders, allow_redirects=False, verify=True)
            output.write("\nThe API Response for DELETING account - \'%s\' in Safe - \'%s for the Address - \'%s\'\' is < %s >\n" % (MoveAcct.AcctDatadict['userName'], MoveAcct.AcctDatadict['safeName'], MoveAcct.AcctDatadict['address'], str(MoveAcctResponse)))

            AddAcctResponse = requests.request('POST', AddAccountUrl, timeout=30, headers=Tokenheaders, data=OnbPayload, allow_redirects=False, verify=True)
            output.write("\nThe API Response for MOVING account - \'%s\' in Safe - \'%s for the Address - \'%s\'\' is < %s >\n" % (MoveAcct.AcctDatadict['userName'], MoveAcct.AcctDatadict['safeName'], MoveAcct.AcctDatadict['address'], str(AddAcctResponse)))

output.write("\n\n                                Script Execution 'END' TimeStamp : %s - %s  \n------------------------------------------------------------------------------------------------------------------------------------------------------\n\n\n" %(today.strftime("%b-%d-%Y"), now.strftime("%H:%M:%S")))

LogOffresponse = requests.request('POST', Logoffurl, timeout=30, headers=Tokenheaders, data=PayLoad, allow_redirects=False, verify=True)
output.close()
